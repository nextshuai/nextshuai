const app = getApp()
const db = wx.cloud.database();
const config = require("../../config.js");
const _ = db.command;
Page({
      data: {
            college: JSON.parse(config.data).college,
            collegeCur: -3,
            nomore: false,
            list: [],
            openid: app.openid,
            name: '',
            scrollTop: -1,
            minscreenHeight: 0,
      },
      onLoad(e) { //判断首页传入的数据类型
            if (e.id == 1) {
                  this.setData({
                        collegeCur: 1,
                        name: '数码产品'
                  })
            }
            if (e.id == 2) {
                  this.setData({
                        collegeCur: 3,
                        name: '服装'
                  })
            }
            if (e.id == 3) {
                  this.setData({
                        collegeCur: 2,
                        name: '装饰品'
                  })
            }
            if (e.id == 4) {
                  this.setData({
                        collegeCur: 4,
                        name: '运动器材'
                  })
            }
            if (e.id == 5) {
                  this.setData({
                        collegeCur: 5,
                        name: '化妆品'
                  })
            }
            if (e.id == 6) {
                  this.setData({
                        collegeCur: 0,
                        name: '学习用品'
                  })
            }
            if (e.id == 7) {
                  this.setData({
                        collegeCur: 6,
                        name: '交通工具'
                  })
            } if (e.id == 8) {
                  this.setData({
                        collegeCur: 7,
                        name: '其他'
                  })
            }

      },
      getList() {
            wx.showLoading({
                  title: '加载中',
            })
            let that = this;
            var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
            db.collection('publish').where({
                  status: 0,
                  dura: _.gt(new Date().getTime()),
                  collegeid: collegeid
            }).orderBy('creat', 'desc').limit(20).get({
                  success: function (res) {
                        wx.stopPullDownRefresh(); //暂停刷新动作
                        wx.hideLoading();
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true,
                                    list: [],
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true,
                                    page: 0,
                                    list: res.data,
                              })
                        } else {
                              that.setData({
                                    page: 0,
                                    list: res.data,
                                    nomore: false,
                              })
                        }
                  }
            })
      },
      more() {
            let that = this;
            if (that.data.nomore || that.data.list.length < 20) {
                  return false
            }
            let page = that.data.page + 1;
            var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
            db.collection('publish').where({
                  status: 0,
                  dura: _.gt(new Date().getTime()),
                  collegeid: collegeid
            }).orderBy('creat', 'desc').skip(page * 20).limit(20).get({
                  success: function (res) {
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true
                              })
                        }
                        that.setData({
                              page: page,
                              list: that.data.list.concat(res.data)
                        })
                  },
                  fail() {
                        wx.hideLoading();
                        wx.showToast({
                              title: '获取失败',
                              icon: 'none'
                        })
                  }
            })
      },
      onReachBottom() {
            this.more();
      },
      //下拉刷新
      onPullDownRefresh() {
            this.getList();
      },
      //跳转详情
      detail(e) {
            let that = this;
            wx.navigateTo({
                  url: '/pages/detail/detail?scene=' + e.currentTarget.dataset.id,
            })
      },
      onShareAppMessage() {
            return {
                  title: JSON.parse(config.data).share_title,
                  imageUrl: JSON.parse(config.data).share_img,
                  path: '/pages/start/start'
            }
      },

      onShow() {
            this.getList()
      },
      back() {
            wx.navigateBack({
                  delta: 1,
            })
      },
      back_home() {
            wx.switchTab({
                  url: '../index/index',
            })
      },
      toTop() {
            wx.pageScrollTo({
                  scrollTop: -1,
                  duration: 300
            })
      },
      getHeight(n) {
            var _this = this;
            wx.getSystemInfo({
                  success: function (res) {
                        _this.data.minscreenHeight = res.windowHeight * n
                  }
            })
      },
      onPageScroll(e) { // 获取滚动条当前位置
            this.setData({
                  scrollTop: e.scrollTop
            })
      },
      onLaunch() {
            this.getHeight(1)
      },
})