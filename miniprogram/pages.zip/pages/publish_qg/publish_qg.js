const db = wx.cloud.database();
const app = getApp();
const config = require("../../config.js");
Page({
      data: {
            checked: false,
            isExist: '',
            systeminfo: app.systeminfo,
            entime: {
                  enter: 600,
                  leave: 300
            }, //进入褪出动画时长
            college: JSON.parse(config.data).college.splice(1),
            steps: [{
                  text: '步骤一',
                  desc: '补充物品信息'
            },
            {
                  text: '步骤二',
                  desc: '发布成功',
            },
            ],
      },
      //恢复初始态
      initial() {
            let that = this;
            that.setData({
                  dura: 30,
                  price: 15,
                  show_b: true,
                  show_c: false,
                  active: 0,
                  desc_counts: 0,
                  describe: '',
                  good: '',
                  kindid: 0,
                  showorhide: true,

            })
      },
      onLoad() {
            this.initial();

      },
      onShow() {

      },
      //价格输入改变
      priceChange(e) {
            this.data.price = e.detail;
      },
      //时长才输入改变
      duraChange(e) {
            this.data.dura = e.detail;
      },
      //物品输入
      goodInput(e) {
            this.data.good = e.detail.value
      },
      //输入描述
      describeInput(e) {
            let that = this;
            that.setData({
                  desc_counts: e.detail.cursor,
                  describe: e.detail.value,
            })
      },
      //发布校检
      check_pub() {
            // 检验授权选项
            let that = this;
            let event = that.data.checked;
            if (event == false) {
                  wx.showToast({
                        title: '请授权订单提醒',
                        icon: 'none',
                        duration: 2000
                  });
                  return false;
            }
            that.publish();
      },
      //正式发布
      publish() {
            let that = this;
            if (!app.openid) {
                  wx.showModal({
                        title: '温馨提示',
                        content: '该功能需要注册方可使用，是否马上去注册',
                        success(res) {
                              if (res.confirm) {
                                    wx.navigateTo({
                                          url: '/pages/login/login',
                                    })
                              }
                        }
                  })
                  return false
            }
            if (that.data.good == '') {
                  wx.showToast({
                        title: '请输入商品名称',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.describe == '') {
                  wx.showToast({
                        title: '请输入商品的详细描述',
                        icon: 'none',
                  });
                  return false;
            }
            if (that.data.notes == '') {
                  wx.showToast({
                        title: '请输入您的联系方式',
                        icon: 'none',
                  });
                  return false;
            }
            wx.showModal({
                  title: '温馨提示',
                  content: '经检测您填写的信息无误，是否马上发布？',
                  success(res) {
                        if (res.confirm) {
                              db.collection('publish_qg').add({
                                    data: {
                                          creat: new Date().getTime(),
                                          dura: new Date().getTime() + that.data.dura * (24 * 60 * 60 * 1000),
                                          status: 0, //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；3、交易作废，退还买家钱款
                                          price: that.data.price, //售价
                                          collegeid: 0,
                                          userInfo: app.userinfo,
                                          bookinfo: {
                                                good: that.data.good,
                                                describe: that.data.describe,
                                          },
                                          key: that.data.good,
                                    },
                                    success(e) {
                                          console.log(e)
                                          that.setData({
                                                show_b: false,
                                                show_c: true,
                                                active: 2,
                                                detail_id: e._id
                                          });
                                          wx.showToast({
                                                title: '正在上传...',
                                                icon: 'loading',
                                                mask: true,
                                                duration: 1000
                                          })
                                          that.setData({
                                                show_b: false,
                                                show_c: true,
                                                active: 2,
                                                detail_id: e._id,
                                          });
                                          //滚动到顶部
                                          wx.pageScrollTo({
                                                scrollTop: 0,
                                          })
                                    }
                              })
                        }
                  }
            })
      },
      detail() {
            let that = this;
            wx.navigateTo({
                  url: '/pages/detail/detail?scene=' + that.data.detail_id,
            })
      },

      onChange(event) {
            if (event.detail == true) {
                  wx.requestSubscribeMessage({
                        tmplIds: ['uyP7eP6BF3n_pP4ZUU7PLkm7AQ22seeqdaUPSA4nSFg', 'NtMxfprcAtf_YlTKIixSzMR1b1vn-iLjABKKCkDXuXE'], //这里填入我们生成的模板id
                        success(res) {
                              console.log('授权成功', res)
                        },
                        fail(res) {
                              console.log('授权失败', res)
                        }
                  })
            }
            this.setData({
                  checked: event.detail,
            });
      },
      //获取授权的点击事件
      shouquan() {
            wx.requestSubscribeMessage({
                  tmplIds: ['uyP7eP6BF3n_pP4ZUU7PLkm7AQ22seeqdaUPSA4nSFg', 'NtMxfprcAtf_YlTKIixSzMR1b1vn-iLjABKKCkDXuXE'], //这里填入我们生成的模板id
                  success(res) {
                        console.log('授权成功', res)
                  },
                  fail(res) {
                        console.log('授权失败', res)
                  }
            })
      },
})