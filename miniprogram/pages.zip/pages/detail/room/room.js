const app = getApp()
const db = wx.cloud.database();
Page({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: null,
    logged: false,
    takeSession: false,
    requestResult: '',
    //chatRoomEnvId: 'release-f8415a',
    chatRoomCollection: 'chatroom',
    chatRoomGroupId: '',
    chatRoomGroupName: '聊天室',
    // functions for used in chatroom components
    onGetUserInfo: null,
    getOpenID: null,
    user: null
  },

  onLoad: function (opentions) {  //此处不建议修改，容易出错，下面类容都不建议修改，容易出错
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            // desc: '展示用户信息',
            success: res => {
              db.collection('user').where({
                _openid: app.openid
              }).get({
                success: re => {
                  console.log("数据", re)
                  this.setData({
                    avatarUrl: re.data[0].info.avatarUrl,
                    userInfo: re.data[0].info
                  })
                }
              })
            }
          })
        }
      }
    })

    this.setData({
      onGetUserInfo: this.onGetUserInfo,
      getOpenID: this.getOpenID,
      chatRoomGroupId: opentions.id
    })

    wx.getSystemInfo({
      success: res => {
        console.log('system info', res)
        if (res.safeArea) {
          const {
            top,
            bottom
          } = res.safeArea
          this.setData({
            containerStyle: `padding-top: ${(/ios/i.test(res.system) ? 10 : 20) + top}px; padding-bottom: ${20 + res.windowHeight - bottom}px`,
          })
        }
      },
    })
  },

  getOpenID: async function () {
    if (app.openid) {
      return app.openid
    }
    const {
      result
    } = await wx.cloud.callFunction({
      name: 'login',
    })
    return result.openid
  },

  onGetUserInfo(e) {
    if (!this.logged && e.detail.userInfo) {
      wx.getUserProfile({
        desc: '展示用户信息',
        success: res => {
          this.setData({
            logged: true,
            avatarUrl: res.userInfo.avatarUrl,
            userInfo: res.userInfo
          })
        }
      })
    }
  },

  onShareAppMessage() {
    return {
      title: '聊天室',
      path: '/pages/detail/room/room',
    }

  },



  go() {
    wx.navigateTo({
      url: '/pages/message/message',
    })
  }

})