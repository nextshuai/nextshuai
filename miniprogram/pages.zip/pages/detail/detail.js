const app = getApp()
const db = wx.cloud.database();
const config = require("../../config.js");
const _ = db.command;
let obj = ''
Page({

      /**
       * 页面的初始数据
       */
      data: {
            ids: '',
            shoucang: false,
            first_title: true,
            place: '',
            roomID: '',
            goodssaller: '',
            openid: '',
            imgs: [],
            isShow: true,
            status: 0,
            avatarUrl: '',
            buyerInfo: [],
            isExist: Boolean,
            address: '',
            showShare: false,
            options: [
                  { name: '微信', icon: 'wechat', openType: 'share' },
                  { name: '二维码', icon: 'qrcode', bindtap: "createQrcode" },
            ],
      },
      onLoad(e) {
            obj = e;
            this.setData({
                  ids: e.scene
            })
            this.getuserdetail();
            this.data.id = e.scene;
            this.getPublish(e.scene);
            if (app.openid) {
                  this.setData({
                        openid: app.openid
                  })
            } else {
                  this.selectComponent('#message').show()
                  return false
            }
            this.getBuyer(this.data.openid)
            setTimeout(() => {
                  this.isShoucang()
            }, 300)
      },

      //获取买家信息
      getBuyer(m) {
            let that = this;
            db.collection('user').where({
                  _openid: m
            }).get({
                  success: function (res) {
                        wx.hideLoading();
                        that.setData({
                              buyerInfo: res.data[0]
                        })
                  }
            })
      },
      // 聊天跳转
      goo(e) {
            if (!app.openid) {
                  this.selectComponent('#message').show()
            } else {
                  var myid = this.data.openid;
                  var sallerid = this.data.goodssaller;
                  wx.cloud.init({
                        env: 'cloud1-2gdd2s9o9f6b260f',
                        traceUser: true
                  });
                  //初始化数据库
                  const db = wx.cloud.database();
                  if (myid != sallerid) {
                        db.collection('rooms').where({
                              p_b: myid,
                              p_s: sallerid
                        }).get().then(res => {
                              if (res.data.length > 0) {
                                    this.setData({
                                          roomID: res.data[0]._id
                                    })
                                    db.collection("rooms").doc(res.data[0]._id).update({
                                          data: {
                                                deleted: 0
                                          },
                                    }), //如没有记录，则新增聊天室，0代表买家，1代表卖家
                                          wx.navigateTo({
                                                url: 'room/room?id=' + this.data.roomID,
                                          })
                              } else {
                                    db.collection('rooms').add({ //有则直接使用
                                          data: {
                                                p_b: myid,
                                                p_s: sallerid,
                                                deleted: 0
                                          },
                                    }).then(res => {
                                          this.setData({
                                                roomID: res._id
                                          })
                                          wx.navigateTo({
                                                url: 'room/room?id=' + this.data.roomID,
                                          })
                                    })
                              }
                        })
                  } else {
                        wx.showToast({
                              title: '无法和自己建立聊天',
                              icon: 'none',
                              duration: 1500
                        })
                  }
            }
      },


      changeTitle(e) {
            let that = this;
            that.setData({
                  first_title: e.currentTarget.dataset.id
            })
      },
      //获取发布信息
      getPublish(e) {
            let that = this;
            db.collection('publish').doc(e).get({
                  success: function (res) {
                        that.setData({
                              collegeName: JSON.parse(config.data).college[parseInt(res.data.collegeid)],
                              publishinfo: res.data
                        })
                        that.getSeller(res.data._openid)
                  }
            })
      },
      //获取卖家信息
      getSeller(m, n) {
            let that = this;
            db.collection('user').where({
                  _openid: m
            }).get({
                  success: function (res) {
                        that.setData({
                              userinfo: res.data[0],
                              goodssaller: res.data[0]._openid
                        })
                        that.getBook(n)
                  }
            })
      },
      //购买检测
      buy() {
            var myid = this.data.openid;
            var sallerid = this.data.goodssaller;
            let that = this;
            if (myid == sallerid) {
                  wx.showToast({
                        title: '自己买不了自己的噢！',
                        icon: 'none',
                        duration: 1500
                  })
                  return false
            }
            if (!app.openid) {
                  this.selectComponent('#message').show()
                  return false
            }
            if (that.data.publishinfo.deliveryid == 1) {
                  if (that.data.place == '') {
                        wx.hideLoading();
                        wx.showToast({
                              title: '请输入您的收货地址',
                              icon: 'none'
                        })
                        return false
                  }
            }
            that.toust();

      },
      toust() {
            this.selectComponent('#dialog').show()
      },
      //获取订单状态
      getStatus() {
            let that = this;
            let _id = that.data.publishinfo._id;
            this.selectComponent('#dialog').hide()
            db.collection('publish').doc(_id).get({
                  success(e) {
                        if (e.data.status == 0) {
                              that.creatOrder(_id);
                        }
                        if (e.data.status == 1) {
                              wx.showToast({
                                    title: '该物品刚刚被抢光了~',
                                    icon: 'none'
                              })
                        }
                        if (e.data.status == 2) {
                              wx.showToast({
                                    title: '该物品已出售',
                                    icon: 'none'
                              })
                        }
                        if (e.data.status == 3) {
                              wx.showToast({
                                    title: '该物品已下架',
                                    icon: 'none'
                              })
                        }
                  }
            })
      },
      //创建订单
      creatOrder(iid) {
            let that = this;

            db.collection('order').where({
                  _id: iid
            }).get().then(res => {
                  console.log(res.data);
                  if (res.data.length > 0) {
                        that.setData({
                              isExist: true
                        })
                        console.log("isExist:" + that.data.isExist)
                  } else {
                        that.setData({
                              isExist: false
                        })
                        console.log("isExist:" + that.data.isExist)
                  }
            })

            wx.showModal({
                  title: '确认提示',
                  content: '是否确认下单购买此商品？',
                  success(res) {
                        if (res.confirm) {
                              if (!that.data.isExist) {
                                    wx.cloud.callFunction({
                                          // 云函数名称
                                          name: 'node',
                                          // 传给云函数的参数
                                          data: {
                                                _id: iid,
                                                status: 1
                                          },
                                          success: function (res) {
                                                console.log(res)
                                          },
                                          fail: console.error
                                    })
                                    wx.getUserInfo({
                                          success: function (res) {
                                                that.setData({
                                                      buyerName: res.userInfo.nickName,
                                                      avatarUrl: res.userInfo.avatarUrl,
                                                })
                                          },
                                          fail() {
                                                console.log("调用getUserinfo失败")
                                          }
                                    })
                                    db.collection('publish').doc({
                                          iid
                                    }).update({
                                          data: {
                                                status: 1
                                          },
                                          success() {
                                                wx.hideLoading();
                                                // that.getList();
                                                db.collection('order').add({
                                                      data: {
                                                            creat: new Date().getTime(),
                                                            status: 1, //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；
                                                            price: that.data.publishinfo.price, //售价
                                                            deliveryid: that.data.publishinfo.deliveryid, //0自1配
                                                            ztplace: that.data.publishinfo.place, //自提时地址
                                                            psplace: that.data.place, //配送时买家填的地址
                                                            bookinfo: {
                                                                  describe: that.data.publishinfo.bookinfo.describe,
                                                                  pic: that.data.publishinfo.bookinfo.pic,
                                                                  good: that.data.publishinfo.bookinfo.good,
                                                            },
                                                            buyerInfo: that.data.buyerInfo,
                                                            seller: that.data.publishinfo._openid,
                                                            sellid: that.data.publishinfo._id,
                                                            _id: that.data.publishinfo._id,
                                                      },
                                                      success() {
                                                            that.getAddress()
                                                            that.send(that.data.goodssaller)
                                                            wx.showToast({
                                                                  title: '成功预订！',
                                                                  icon: 'success',
                                                                  duration: 1000
                                                            })
                                                            setTimeout(function () {
                                                                  wx.navigateTo({
                                                                        url: '/pages/order/list/list',
                                                                  })
                                                            }, 1000)
                                                      },
                                                      fail() {
                                                            wx.hideLoading();
                                                            wx.showToast({
                                                                  title: '发生异常，请及时和开发者联系处理！',
                                                                  icon: 'none'
                                                            })
                                                      }
                                                })
                                          },
                                          fail() {
                                                wx.hideLoading();
                                                wx.showToast({
                                                      title: '操作失败',
                                                      icon: 'none'
                                                })
                                          }
                                    })
                                    that.onLoad(obj);
                              } else {
                                    wx.cloud.callFunction({
                                          // 云函数名称
                                          name: 'node',
                                          // 传给云函数的参数
                                          data: {
                                                _id: iid,
                                                status: 1
                                          },
                                          success: function (res) {
                                                console.log(res)
                                          },
                                          fail: console.error
                                    })
                                    db.collection('publish').doc({
                                          iid
                                    }).update({
                                          data: {
                                                status: 1
                                          },
                                          success() {
                                                wx.hideLoading();
                                                wx.cloud.callFunction({
                                                      // 云函数名称
                                                      name: 'pay',
                                                      // 传给云函数的参数
                                                      data: {
                                                            $url: "changeO", //云函数路由参数
                                                            _id: iid,
                                                            status: 1
                                                      },
                                                      success() {
                                                            that.getAddress()
                                                            that.send(that.data.goodssaller)
                                                            wx.showToast({
                                                                  title: '成功预订！',
                                                                  icon: 'success',
                                                                  duration: 3000
                                                            })
                                                      },
                                                      fail() {
                                                            wx.hideLoading();
                                                            wx.showToast({
                                                                  title: '发生异常，请及时和开发者联系处理！',
                                                                  icon: 'none'
                                                            })
                                                      }
                                                })
                                          },
                                          fail() {
                                                wx.hideLoading();
                                                wx.showToast({
                                                      title: '操作失败',
                                                      icon: 'none'
                                                })
                                          }
                                    })
                                    that.onLoad(obj);
                              }
                        }
                  }
            })

      },

      //发送模板消息到指定用户,推送之前要先获取用户的openid
      send(openid) {
            let that = this;
            wx.cloud.callFunction({
                  name: "sendMsg",
                  data: { //与自己的模板信息对应
                        openid: openid,
                        status: '买家已预定', //0在售；1买家已付款，但卖家未发货；2买家确认收获，交易完成；
                        address: that.data.address,
                        describe: that.data.publishinfo.bookinfo.describe,
                        good: that.data.publishinfo.bookinfo.good,
                        nickName: that.data.buyerInfo.info.nickName,
                        color: 'red'
                  }
            }).then(res => {
                  console.log("推送消息成功", res)
            }).catch(res => {
                  console.log("推送消息失败", res)
            })
      },

      //路由
      go(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.go,
            })
      },
      //地址输入
      placeInput(e) {
            this.data.place = e.detail.value
      },
      //为了数据安全可靠，每次进入获取一次用户信息
      getuserdetail() {
            if (!app.openid) {
                  wx.cloud.callFunction({
                        name: 'regist', // 对应云函数名
                        data: {
                              $url: "getid", //云函数路由参数
                        },
                        success: re => {
                              db.collection('user').where({
                                    _openid: re.result
                              }).get({
                                    success: function (res) {
                                          if (res.data.length !== 0) {
                                                app.openid = re.result;
                                                app.userinfo = res.data[0];
                                                console.log(app)
                                          }
                                          console.log(res)
                                    }
                              })
                        }
                  })
            }
      },

      //图片点击事件
      img: function (event) {
            let arr = [];
            arr.push(this.data.publishinfo.bookinfo.imgs);
            var src = event.currentTarget.dataset.src; //获取data-src
            // var imgList = that.data.result.images_fileID;
            //图片预览
            wx.previewImage({
                  current: src, // 当前显示图片的http链接
                  urls: arr[0] // 需要预览的图片http链接列表
            })
      },

      /**
       * 获取地址
       */
      getAddress() {
            let that = this;
            if (that.data.publishinfo.deliveryid == 0) {
                  that.setData({
                        address: that.data.publishinfo.place
                  })
            } else {
                  that.setData({
                        address: that.data.place
                  })
            }
      },
      back() {
            wx.navigateBack({
                  delta: 1,
            })
      },
      back_home() {
            wx.switchTab({
                  url: '../index/index',
            })
      },
      onClick(event) {
            this.setData({ showShare: true });
      },

      onClose() {
            this.setData({ showShare: false });
      },

      onSelect(event) {
            this.onClose();
      },
      //   收藏功能
      onShouCang() {
            db.collection('collection').add({
                  data: {
                        goodsInfo: this.data.publishinfo,
                        id: this.data.ids
                  }
            }).then(res => {
                  wx.showToast({
                        title: '收藏成功',
                        icon: 'none'
                  })
                  this.setData({
                        shoucang: true
                  })
            })
      },
      InShouCang() {
            this.selectComponent('#dialog1').show()
      },
      guanbi() {
            this.selectComponent('#dialog1').hide()
      },
      InShouCangAgain() {
            this.selectComponent('#dialog1').hide()
            db.collection('collection').where({
                  _openid: app.openid,
                  id: this.data.ids
            }).remove().then(res => {
                  this.setData({
                        shoucang: false
                  })
                  wx.showToast({
                        title: '取消收藏',
                        icon: 'none'
                  })
            })
      },
      //   查询收藏
      isShoucang() {
            db.collection('collection').where({
                  _openid: app.openid,
                  id: this.data.ids
            }).get().then(res => {
                  if (res.data.length > 0) {
                        this.setData({
                              shoucang: true
                        })
                  }
                  else {
                        this.setData({
                              shoucang: false
                        })
                  }
            })
      },
      onShareAppMessage() {
            return {
                  title: `❤ 解忧旧物小铺 ~ 来看看这件物品把👏👏`,
                  path: `/pages/detail/detail?scene=` + this.data.ids,
                  imageUrl: '../../images/file.jpg'
            }
      },
})