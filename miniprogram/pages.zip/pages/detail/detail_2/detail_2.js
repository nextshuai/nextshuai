const app = getApp()
const db = wx.cloud.database();
const config = require("../../../config.js");
const _ = db.command;
let obj = ''
Page({

      /**
       * 页面的初始数据
       */
      data: {
            first_title: true,
            roomID: '',
            goodssaller: '',
            openid: '',
            isShow: true,
            status: 0,
            avatarUrl: '',
            buyerInfo: [],
            isExist: Boolean,
            address: '',
            showShare: false,
            options: [
                  { name: '微信', icon: 'wechat', openType: 'share' },
                  { name: '二维码', icon: 'qrcode', bindtap: "createQrcode" },
            ],
      },
      onLoad(e) {
            obj = e;
            this.data.id = e.scene;
            this.getuserdetail()
            this.getPublish(e.scene);
            if (app.openid) {
                  this.setData({
                        openid: app.openid
                  })
            } else {
                  console.log("no openid");
                  this.selectComponent('#message').show()
                  return false
            }
            this.getBuyer(this.data.openid)
            wx.showShareMenu({
                  withShareTicket: true,
                  menus: ['shareAppMessage', 'shareTimeline']
            })
      },
      //获取买家信息
      getBuyer(m) {
            let that = this;
            db.collection('user').where({
                  _openid: m
            }).get({
                  success: function (res) {
                        wx.hideLoading();
                        that.setData({
                              buyerInfo: res.data[0]
                        })
                  }
            })
      },
      goo(e) {
            var myid = this.data.openid;
            var sallerid = this.data.goodssaller;
            wx.cloud.init({
                  env: 'cloud1-2gdd2s9o9f6b260f',
                  traceUser: true
            });
            //初始化数据库
            const db = wx.cloud.database();
            if (myid != sallerid) {
                  db.collection('rooms').where({
                        p_b: myid,
                        p_s: sallerid
                  }).get().then(res => {
                        console.log(res.data);
                        if (res.data.length > 0) {
                              this.setData({
                                    roomID: res.data[0]._id
                              })
                              db.collection("rooms").doc(res.data[0]._id).update({
                                    data: {
                                          deleted: 0
                                    },
                              }),
                                    wx.navigateTo({
                                          url: 'room/room?id=' + this.data.roomID,
                                    })
                        } else {
                              db.collection('rooms').add({
                                    data: {
                                          p_b: myid,
                                          p_s: sallerid,
                                          deleted: 0
                                    },
                              }).then(res => {
                                    console.log(res)
                                    this.setData({
                                          roomID: res._id
                                    })
                                    wx.navigateTo({
                                          url: 'room/room?id=' + this.data.roomID,
                                    })
                              })
                        }
                  })
            } else {
                  wx.showToast({
                        title: '无法和自己建立聊天',
                        icon: 'none',
                        duration: 1500
                  })
            }
      },


      changeTitle(e) {
            let that = this;
            that.setData({
                  first_title: e.currentTarget.dataset.id
            })
      },
      //获取发布信息
      getPublish(e) {
            let that = this;
            db.collection('publish_qg').doc(e).get({
                  success: function (res) {
                        console.log("直立式", res)
                        that.setData({
                              collegeName: JSON.parse(config.data).college[parseInt(res.data.collegeid) + 1],
                              publishinfo: res.data
                        })
                        that.getSeller(res.data._openid)
                  }
            })
      },
      //获取卖家信息
      getSeller(m, n) {
            let that = this;
            db.collection('user').where({
                  _openid: m
            }).get({
                  success: function (res) {
                        console.log("用户信息", res)
                        console.log(res.data[0]._openid);
                        that.setData({
                              qqnum: res.data[0].qqnum,
                              userinfo: res.data[0],
                              goodssaller: res.data[0]._openid
                        })
                        that.getBook(n)
                  }
            })
      },
      //路由
      go(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.go,
            })
      },
      //为了数据安全可靠，每次进入获取一次用户信息
      getuserdetail() {
            if (!app.openid) {
                  wx.cloud.callFunction({
                        name: 'regist', // 对应云函数名
                        data: {
                              $url: "getid", //云函数路由参数
                        },
                        success: re => {
                              db.collection('user').where({
                                    _openid: re.result
                              }).get({
                                    success: function (res) {
                                          if (res.data.length !== 0) {
                                                app.openid = re.result;
                                                app.userinfo = res.data[0];
                                                console.log(app)
                                          }
                                          console.log(res)
                                    }
                              })
                        }
                  })
            }
      },
      /**
       * 获取地址
       */
      getAddress() {
            let that = this;
            if (that.data.publishinfo.deliveryid == 0) {
                  that.setData({
                        address: that.data.publishinfo.place
                  })
            } else {
                  that.setData({
                        address: that.data.place
                  })
            }
      },
      onClick(event) {
            this.setData({ showShare: true });
      },

      onClose() {
            this.setData({ showShare: false });
      },
      onShareAppMessage() {
            return {
                  title: `❤ 解忧旧物小铺 ~ 来看看这件物品把👏👏`,
                  path: `/pages/detail/detail_2/detail_2?scene=` + obj,
                  imageUrl: '../../../images/file.jpg'
            }
      },
})