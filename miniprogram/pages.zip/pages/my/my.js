const app = getApp();
const config = require("../../config.js");
const db = wx.cloud.database();
const util = require('../../utils/utils.js')
Page({

      /**
       * 页面的初始数据
       */
      data: {
            showShare: false,
            username: '',
            openid: '',
            roomlist: [],
            ids: '',
            messageNum: 0,
            showShare: false,
            options: [
                  { name: '微信', icon: 'wechat', openType: 'share' },
                  { name: '建议反馈', icon: 'link', openType: 'feedback' }
            ],
            morring: false,
            night: false,
            evening: false,
            date: '',
      },
      // 判断当前时间
      chargeTime() {
            if (parseInt(util.formatTime(this.data.date)) >= 6 && parseInt(util.formatTime(this.data.date)) < 14) {
                  this.setData({
                        morring: true,
                        night: false,
                        evening: false
                  })
            }
            if (parseInt(util.formatTime(this.data.date)) >= 14 && parseInt(util.formatTime(this.data.date)) < 19) {
                  this.setData({
                        evening: true,
                        morring: false,
                        night: false
                  })
            }
            if (parseInt(util.formatTime(this.data.date)) >= 19 || parseInt(util.formatTime(this.data.date)) < 6) {
                  this.setData({
                        evening: false,
                        morring: false,
                        night: true
                  })
            }
      },
      onShow() {
            this.setData({
                  userinfo: app.userinfo
            })
      },
      onLoad: function (options) {
            this.setData({
                  openid: app.openid,
                  date: new Date().getTime(),
            })
            this.checkInfo()
            this.chargeTime()

      },
      goo() {
            console.log(app.roomlist);
            if (!app.openid) {
                  this.selectComponent('#message').show()
                  return false
            } else {
                  wx.navigateTo({
                        url: '../message/message',
                  })
            }

      },
      go(e) {
            if (e.currentTarget.dataset.status == '1') {
                  if (!app.openid) {
                        this.selectComponent('#message').show()
                        return false
                  }
            }
            wx.navigateTo({
                  url: e.currentTarget.dataset.go
            })
      },
      //展示分享弹窗
      showShare() {
            this.setData({
                  showShare: true
            });
      },
      //关闭弹窗
      closePop() {
            this.setData({
                  showShare: false,
            });
      },
      onShareAppMessage() {
            return {
                  title: `❤ 解忧旧物小铺 ~ 一个专注于宜宾大学城的二手平台👏👏`,
                  path: `/pages/index/index`,
                  imageUrl: '../../images/file.jpg'
            }
      },
      //获取授权的点击事件
      shouquan() {
            wx.requestSubscribeMessage({
                  tmplIds: ['uyP7eP6BF3n_pP4ZUU7PLkm7AQ22seeqdaUPSA4nSFg'], //这里填入我们生成的模板id
                  success(res) {
                        console.log('授权成功', res)
                  },
                  fail(res) {
                        console.log('授权失败', res)
                  }
            })
      },
      //退出登录
      loginOut() {  //实际情况应该为只删除用户端的登录记录，不会删除数据库中的用户信息，但我嫌麻烦，就直接全部删除了
            let that = this   //也可以直接做个假的删除记录，即改变一下当前的值
            wx.showModal({
                  title: '提示',
                  content: '确定要退出登录并删除个人信息吗',
                  success(res) {
                        if (res.confirm) {
                              console.log('用户点击确定')
                              db.collection('user').where({
                                    _openid: app.openid
                              }).get().then(res => {
                                    console.log("数据", res)
                                    that.setData({
                                          ids: res.data[0]._id
                                    })
                                    db.collection('user').doc(that.data.ids).remove().then(res => {
                                          console.log("删除成功")
                                          wx.showToast({
                                                title: '删除成功',
                                                icon: "success",
                                                duration: 2000
                                          })
                                          that.setData({
                                                userinfo: "",
                                                openid: ""
                                          })
                                          wx.setStorageSync('systeminfo', null)
                                    })
                              })
                        } else if (res.cancel) {
                              console.log('用户点击取消')
                        }
                  }
            })
      },

      checkInfo() {
            db.collection('rooms').where({
                  _openid: app.openid
            }).get().then(res => {
                  this.setData({
                        messageNum: res.data.length
                  })
            })
      },
      onClick(event) {
            this.setData({ showShare: true });
      },

      onClose() {
            this.setData({ showShare: false });
      },

      onSelect(event) {
            this.onClose();
      },
      goto(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.goto,
            })
      }
})