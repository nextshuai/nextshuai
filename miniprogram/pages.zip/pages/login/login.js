const db = wx.cloud.database();
const app = getApp();
const config = require("../../config.js");
Page({

      /**
       * 页面的初始数据
       */
      data: {
            ids: -1,
            wxnum: '',
            qqnum: '',
            idcards: '',
            checked: false,
            campus: JSON.parse(config.data).campus,
      },

      onChange(event) {
            if (event.detail == true) {
                  console.log("授权成功")
            }
            this.setData({
                  checked: event.detail,
            });
      },

      choose(e) {
            let that = this;
            that.setData({
                  ids: e.detail.value
            })
      },

      onLoad: function (options) {
            
      },
      //获取用户信息
      getUserProfile(e) {
            let that = this;
            if (that.check() !== false) {
                  // that.check()
                  wx.getUserProfile({
                        desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
                        success: res => {
                              let user = res.userInfo
                              console.log("用户信息", user)
                              that.setData({
                                    userInfo: user,
                              })
                              that.send();
                        },
                        fail: res => {
                              console.log("失败", res)
                        }
                  })
            };
      },

      //校检
      check() {
            let that = this;
            if (this.data.yunxu == true) {
                  //校检校区
                  let ids = that.data.ids;
                  if (ids == -1) {
                        wx.showToast({
                              title: '请先获取您的校园',
                              icon: 'none',
                              duration: 2000
                        });
                        return false;
                  }
            }
            // 检验授权选项
            let event = that.data.checked;
            if (event == false) {
                  wx.showToast({
                        title: '请勾选我已阅读',
                        icon: 'none',
                        duration: 2000
                  });
                  return false;
            }
      },
      //提交表单到数据库
      send() {
            let that = this
            wx.showLoading({
                  title: '正在提交',
            })
            db.collection('user').add({
                  data: {
                        campus: that.data.campus[that.data.ids],
                        stamp: new Date().getTime(),
                        info: that.data.userInfo,
                        useful: true,
                        parse: 0,
                  },
                  success: function (res) {
                        console.log(res)
                        db.collection('user').doc(res._id).get({
                              success: function (res) {
                                    app.userinfo = res.data;
                                    app.openid = res.data._openid;
                                    wx.navigateBack({})
                              },
                        })
                  },
                  fail() {
                        wx.hideLoading();
                        wx.showToast({
                              title: '注册失败，请重新提交',
                              icon: 'none',
                        })
                  }
            })
      },
      knowInfo() {
            wx.navigateTo({
                  url: '/pages/serve/serve',
            })
      },
})