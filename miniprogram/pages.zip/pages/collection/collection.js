const app = getApp()
const db = wx.cloud.database();
const _ = db.command;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    nomore: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.isCollection()
  },


  // 查询收藏
  isCollection() {
    db.collection('collection').where({
      _openid: app.openid
    }).limit(20).get().then(res => { //少量获取，减少时耗
      if (res.data.length == 0) {
        this.setData({
          nomore: true,
          list: [],
        })
        return false;
      }
      if (res.data.length < 20) {
        this.setData({
          nomore: true,
          page: 0,
          list: res.data,
        })
      } else {
        this.setData({
          page: 0,
          list: res.data,
          nomore: false,
        })
      }
    })
  },
  // 删除收藏
  InShouCang(e) {
    wx.showModal({
      title: '提示',
      content: '是否移除我的收藏？',
      success(res) {
        if (res.confirm) {
          db.collection('collection').where({
            _openid: app.openid,
            id: e.currentTarget.dataset.id
          }).remove().then(res => {
            wx.startPullDownRefresh()
            wx.showToast({
              title: '取消收藏成功',
              icon: 'none'
            })

          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  more() {
    let that = this;
    if (that.data.nomore || that.data.list.length < 20) {
      return false
    }
    let page = that.data.page + 1;
    db.collection('collection').where({
      _openid: app.openid
    }).skip(page * 20).limit(20).get({
      success: function (res) {
        if (res.data.length == 0) {
          that.setData({
            nomore: true
          })
          return false;
        }
        if (res.data.length < 20) {
          that.setData({
            nomore: true
          })
        }
        that.setData({
          page: page,
          list: that.data.list.concat(res.data)
        })
      },
      fail() {
        wx.showToast({
          title: '获取失败',
          icon: 'none'
        })
      }
    })
  },
  // 详情跳转
  toDetail(e) {
    wx.navigateTo({
      url: '../detail/detail?scene=' + e.currentTarget.dataset.id,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    this.more();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})