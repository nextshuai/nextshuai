const app = getApp()
const db = wx.cloud.database();
const config = require("../../config.js");
const _ = db.command;
Page({
      data: {
            userinfo: '',
            college: JSON.parse(config.data).college,
            collegeCur: -2,
            nomore: false,
            list: [],
            list2: [],
            openid: app.openid,
            buttons: [
                  {
                        label: '闲置',
                        icon: '../../images/xianzhi.png',
                        hideShadow: true,
                  },
                  {
                        label: '求购',
                        icon: '../../images/qiugou.png',
                        hideShadow: true
                  }
            ],
            scrollTop: -1,
            minscreenHeight: 0,
      },
      onClick(e) {
            if (!app.openid) {
                  this.selectComponent('#message').show()
                  return false
            }
            switch (e.detail.index) {
                  case 0:
                        wx.navigateTo({
                              url: '../publish/publish',
                        })
                        break;
                  case 1:
                        wx.navigateTo({
                              url: '../publish_qg/publish_qg',
                        })
                        break;
            }
      },
      onLoad() {
            this.getuserdetail()
      },
      //跳转搜索
      search() {
            wx.navigateTo({
                  url: '/pages/search/search',
            })
      },
      // 闲置获取数据
      getList(e) {
            wx.showLoading({
                  title: '加载中',
            })
            let that = this;
            if (that.data.collegeCur == -2) {
                  var collegeid = _.neq(-2); //除-2之外所有
            } else {
                  var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
            }
            db.collection('publish').where({
                  status: 0,
                  dura: _.gt(new Date().getTime()),
                  collegeid: collegeid
            }).orderBy('creat', 'desc').limit(20).get({ //数据一次性不建议获取太多，减少时耗
                  success: function (res) {
                        wx.stopPullDownRefresh(); //暂停刷新动作
                        wx.hideLoading();
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true,
                                    list: [],
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true,
                                    page: 0,
                                    list: res.data,
                              })
                        } else {
                              that.setData({
                                    page: 0,
                                    list: res.data,
                                    nomore: false,
                              })
                        }
                  }
            })
      },
      // 求购
      getList_2() {
            wx.showLoading({
                  title: '加载中',
            })
            let that = this;
            db.collection('publish_qg').where({
                  dura: _.gt(new Date().getTime()),
            }).orderBy('creat', 'desc').limit(20).get({
                  success: function (res) {
                        wx.stopPullDownRefresh(); //暂停刷新动作
                        wx.hideLoading();
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true,
                                    list2: [],
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true,
                                    page: 0,
                                    list2: res.data,
                              })
                        } else {
                              that.setData({
                                    page: 0,
                                    list2: res.data,
                                    nomore: false,
                              })
                        }
                  }
            })
      },
      // 获取更多
      more() {
            let that = this;
            if (that.data.nomore || that.data.list.length < 20) {
                  return false
            }
            let page = that.data.page + 1;
            if (that.data.collegeCur == -2) {
                  var collegeid = _.gt(-2); //除-2之外所有
            } else {
                  var collegeid = that.data.collegeCur + '' //小程序搜索必须对应格式
            }
            db.collection('publish').where({
                  status: 0,
                  dura: _.gt(new Date().getTime()),
                  collegeid: collegeid
            }).orderBy('creat', 'desc').skip(page * 20).limit(20).get({
                  success: function (res) {
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true
                              })
                        }
                        that.setData({
                              page: page,
                              list: that.data.list.concat(res.data)
                        })
                  },
                  fail() {
                        wx.hideLoading();
                        wx.showToast({
                              title: '获取失败',
                              icon: 'none'
                        })
                  }
            })
      },
      more_2() {
            let that = this;
            if (that.data.nomore || that.data.list2.length < 20) {
                  return false
            }
            let page = that.data.page + 1;
            db.collection('publish_qg').where({
                  dura: _.gt(new Date().getTime()),
            }).orderBy('creat', 'desc').skip(page * 20).limit(20).get({
                  success: function (res) {
                        if (res.data.length == 0) {
                              that.setData({
                                    nomore: true
                              })
                              return false;
                        }
                        if (res.data.length < 20) {
                              that.setData({
                                    nomore: true
                              })
                        }
                        that.setData({
                              page: page,
                              list2: that.data.list2.concat(res.data)
                        })
                  },
                  fail() {
                        wx.hideLoading();
                        wx.showToast({
                              title: '获取失败',
                              icon: 'none'
                        })
                  }
            })
      },
      // 触底
      onReachBottom() {
            this.more();
            this.more_2()
      },
      //下拉刷新
      onPullDownRefresh() {
            this.getList();
            this.getList_2();
      },
      //跳转详情
      detail(e) {
            wx.navigateTo({
                  url: '/pages/detail/detail?scene=' + e.currentTarget.dataset.id,
            })
      },
      detail_2(e) {
            let that = this;
            wx.navigateTo({
                  url: '/pages/detail/detail_2/detail_2?scene=' + e.currentTarget.dataset.id,
            })
      },

      onShow() {
            this.getList()
            this.getList_2()
      },
      // 导航栏路由携带数据跳转
      go(e) {
            wx.navigateTo({
                  url: '../other/other?id=' + e.currentTarget.dataset.id,
            })
      },

      //为了数据安全可靠，每次进入获取一次用户信息
      getuserdetail() {
            let that = this
            if (!app.openid) {
                  wx.cloud.callFunction({
                        name: 'regist', // 对应云函数名
                        data: {
                              $url: "getid", //云函数路由参数
                        },
                        success: re => {
                              db.collection('user').where({
                                    _openid: re.result
                              }).get({
                                    success: function (res) {
                                          if (res.data.length !== 0) {
                                                that.setData({
                                                      userinfo: res.data[0]
                                                })
                                                app.openid = re.result;
                                                app.userinfo = res.data[0];
                                                console.log(app)
                                          }
                                          console.log(res)
                                    }
                              })
                        }
                  })
            }
      },
      // 归顶
      toTop() {
            wx.pageScrollTo({
                  scrollTop: -1,
                  duration: 300
            })
      },
      getHeight(n) {
            var _this = this;
            wx.getSystemInfo({
                  success: function (res) {
                        _this.data.minscreenHeight = res.windowHeight * n
                  }
            })
      },
      onPageScroll(e) { // 获取滚动条当前位置
            this.setData({
                  scrollTop: e.scrollTop
            })
      },
      onLaunch() {
            this.getHeight(1)
      },
      // 路由
      goto(e) {
            this.selectComponent('#message').hide()
            wx.navigateTo({
                  url: e.currentTarget.dataset.goto,
            })
      }
})