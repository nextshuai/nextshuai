const cloud = require('wx-server-sdk')
cloud.init()
exports.main = async(event, context) => {
  try {
    const result = await cloud.openapi.subscribeMessage.send({
      touser: event.openid, //要推送给那个用户
      page: 'pages/index/index', //要跳转到那个小程序页面
      data: {//推送的内容
        thing6: {
          value: event.nickName
        },
        thing10:{
          value: '申请聊天'
        },
        thing5:{
          value: event.tip
        }
      },
      templateId: 'NtMxfprcAtf_YlTKIixSzMR1b1vn-iLjABKKCkDXuXE' //模板id
    })
    console.log(result)
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}