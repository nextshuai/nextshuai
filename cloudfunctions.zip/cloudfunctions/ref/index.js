const config = {
      appid: 'wx9ead6fbb0165f548', //小程序Appid
      envName: 'cloud1-2gdd2s9o9f6b260f', // 小程序云开发环境ID
      mchid: '1111111111', //商户号，不管，没用
      partnerKey: '1111111111111111111111', //此处填服务商密钥，不管，没用
      pfx: '', //证书初始化，不管，没用
      fileID: 'cloud://cloud1-2gdd2s9o9f6b260f.636c-cloud1-2gdd2s9o9f6b260f-1310396970/goods-pic/ophn04ljGG8M--WUd7Aa5myMEms4/17796.png', //证书云存储id，不管，没用
      actionName:'成工二手商城小程序提现',//，不管，没用
      rate:1 //提现收取利率，1指的是每笔收取1%，不管，没用
};

/*
下
面
不
用
管
*/
const cloud = require('wx-server-sdk')
cloud.init({
      env: config.envName
})

const db = cloud.database();
const tenpay = require('tenpay'); //支付核心模块
exports.main = async(event, context) => {

      let userInfo = (await db.collection('user').doc(event.userid).get()).data;
      if (parseInt(userInfo.parse)<=parseInt(event.num)){
            return 0;
      }
      //首先获取证书文件
     let fileres = await cloud.downloadFile({
            fileID: config.fileID,
      })
      config.pfx = fileres.fileContent
      let pay = new tenpay(config,true)
      let result = await pay.transfers({
            partner_trade_no: 'bookreflect' + Date.now() + event.num,
            openid: userInfo._openid,
            check_name: 'NO_CHECK',
            amount: parseInt(event.num) * (100 - config.rate),
            desc: config.actionName,
      });
      if (result.result_code == 'SUCCESS') {
            //成功后操作
            //以下是进行余额计算
            let re=await db.collection('user').doc(event.userid).update({
                  data: {
                        parse: userInfo.parse - parseInt(event.num)
                  }
            });
            return re
      }
}
